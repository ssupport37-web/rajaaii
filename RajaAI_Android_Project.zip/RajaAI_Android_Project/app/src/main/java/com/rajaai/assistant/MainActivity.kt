package com.rajaai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RajaApp() }
    }
}

private data class ChatLine(val fromUser: Boolean, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RajaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("raja_settings", 0) }
    var backend by remember { mutableStateOf(prefs.getString("backend", "") ?: "") }
    var draft by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    val lines = remember { mutableStateListOf(ChatLine(false, "Assalam-o-alaikum! Main Raja AI hoon. Roman Urdu mein baat karein.")) }
    val scope = rememberCoroutineScope()
    val api = remember { GeminiApi() }

    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { result ->
            if (result == TextToSpeech.SUCCESS) {
                tts?.let { chooseRomanUrduVoice(it) }
            }
        }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    fun speak(text: String) {
        tts?.let { engine ->
            chooseRomanUrduVoice(engine)
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "raja_reply")
        }
    }

    fun localAction(raw: String): Boolean {
        val s = raw.lowercase(Locale.ROOT)
        when {
            s.contains("youtube") && (s.contains("open") || s.contains("kholo") || s.contains("chalao")) -> {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                val msg = "YouTube khol raha hoon."
                lines.add(ChatLine(false, msg)); speak(msg); return true
            }
            (s.contains("google") || s.contains("search")) && (s.contains("open") || s.contains("kholo")) -> {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                val msg = "Google khol raha hoon."
                lines.add(ChatLine(false, msg)); speak(msg); return true
            }
            s.contains("settings") && (s.contains("open") || s.contains("kholo")) -> {
                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                val msg = "Phone settings khol raha hoon."
                lines.add(ChatLine(false, msg)); speak(msg); return true
            }
            s.contains("time") || s.contains("waqt") -> {
                val msg = "Abhi waqt ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())} hai."
                lines.add(ChatLine(false, msg)); speak(msg); return true
            }
            s.contains("date") || s.contains("tareekh") -> {
                val msg = "Aaj ${java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("ur", "PK")).format(java.util.Date())} hai."
                lines.add(ChatLine(false, msg)); speak(msg); return true
            }
        }
        return false
    }

    fun send(text: String) {
        val q = text.trim()
        if (q.isEmpty() || busy) return
        lines.add(ChatLine(true, q)); draft = ""
        if (localAction(q)) return
        if (backend.isBlank()) {
            val msg = "Pehle Settings mein apna secure HTTPS backend URL add karein."
            lines.add(ChatLine(false, msg)); speak(msg); return
        }
        busy = true; status = "Gemini se rabta ho raha hai..."
        scope.launch {
            try {
                val answer = withContext(Dispatchers.IO) { api.chat(backend, q) }
                lines.add(ChatLine(false, answer)); speak(answer); status = "Ready"
            } catch (e: Exception) {
                val msg = "Connection masla: ${e.message ?: "Dobara koshish karein."}"
                lines.add(ChatLine(false, msg)); speak(msg); status = "Connection error"
            } finally { busy = false }
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) send(spoken) else status = "Awaaz samajh nahi aayi. Dobara koshish karein."
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Raja AI se baat karein")
            }
            runCatching { speechLauncher.launch(intent) }.onFailure { status = "Speech service available nahi." }
        } else status = "Microphone permission nahi mili."
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF54C8FF), background = Color(0xFF07111F),
        surface = Color(0xFF101F32), onSurface = Color.White
    )) {
        Scaffold(containerColor = Color(0xFF07111F), topBar = {
            TopAppBar(
                title = { Column { Text("RAJA AI", fontWeight = FontWeight.Bold, color = Color.White); Text("Gemini • Roman Urdu", fontSize = 12.sp, color = Color(0xFF8CCFFF)) } },
                actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0B192A))
            )
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(14.dp)) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.TopCenter) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(10.dp))
                        Box(Modifier.size(126.dp).background(Brush.radialGradient(listOf(Color(0xFF167DC2), Color(0xFF0B2947), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
                            Text("RAJA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                        }
                        Text(status, color = Color(0xFF8CCFFF), fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                    }
                    LazyColumn(Modifier.fillMaxSize().padding(top = 165.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(lines) { line ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                                Surface(color = if (line.fromUser) Color(0xFF124C75) else Color(0xFF14283D), shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                    Text(line.text, Modifier.padding(12.dp), color = Color.White)
                                }
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f), placeholder = { Text("Raja se baat karein...") }, maxLines = 3)
                    IconButton(onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Raja AI se baat karein")
                            }
                            runCatching { speechLauncher.launch(intent) }.onFailure { status = "Speech service available nahi." }
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }) { Icon(Icons.Default.Mic, "Speak", tint = Color(0xFF54C8FF)) }
                    IconButton(onClick = { send(draft) }, enabled = !busy) { Icon(Icons.Default.Send, "Send", tint = Color(0xFF54C8FF)) }
                }
                Text("Voice commands: 'YouTube kholo', 'Google kholo', 'Settings kholo', 'time batao'", color = Color(0xFF7894AD), fontSize = 10.sp)
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Raja AI Settings") },
                text = {
                    Column {
                        Text("Backend HTTPS URL (Render par deployed /chat service)")
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(value = backend, onValueChange = { backend = it }, placeholder = { Text("https://your-service.onrender.com") })
                        Spacer(Modifier.height(8.dp))
                        Text("Gemini API key app mein nahi rakhi jati. Isay backend ke environment variable mein secure rakhein.", fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.edit().putString("backend", backend.trim().trimEnd('/')).apply()
                        showSettings = false
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
            )
        }
    }
}

private fun chooseRomanUrduVoice(engine: TextToSpeech) {
    engine.language = Locale("ur", "PK")
    val voices: Set<Voice> = engine.voices ?: emptySet()
    val urdu = voices.filter { it.locale.language == "ur" }
    val maleHint = urdu.firstOrNull { v -> listOf("male", "man", "masculine").any { v.name.contains(it, true) } }
    if (maleHint != null) engine.voice = maleHint
}

private object SpeechResultHolder { var callback: ((String) -> Unit)? = null }
