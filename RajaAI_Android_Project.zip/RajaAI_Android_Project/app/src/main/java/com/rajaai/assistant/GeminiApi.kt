package com.rajaai.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun chat(baseUrl: String, message: String): String {
        val cleanUrl = baseUrl.trim().trimEnd('/')
        require(cleanUrl.startsWith("https://")) { "Settings mein valid HTTPS backend URL likhein." }
        val payload = JSONObject().put("message", message)
        val request = Request.Builder()
            .url("$cleanUrl/chat")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val detail = runCatching { JSONObject(body).optString("error") }.getOrDefault("")
                throw IllegalStateException(detail.ifBlank { "Backend error: ${response.code}" })
            }
            val json = JSONObject(body)
            return json.optString("reply").ifBlank { "Mujhe jawab nahi mila. Dobara koshish karein." }
        }
    }
}
