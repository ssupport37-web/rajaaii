import os
import requests
from flask import Flask, jsonify, request

app = Flask(__name__)
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

SYSTEM_INSTRUCTION = (
    "Tum Raja AI ho, aik helpful Android personal assistant. "
    "Hamesha Roman Urdu mein jawab do, jab tak user doosri zaban na maange. "
    "Lehja mohtaram, friendly aur mukhtasar rakho. "
    "Phone actions sirf tab app khud handle karti hai jab user supported command de; "
    "warna user ko saaf batao ke tum yahan se action execute nahi kar sakte."
)

@app.get("/")
def home():
    return jsonify({"service": "Raja AI backend", "status": "ok"})

@app.post("/chat")
def chat():
    if not GEMINI_API_KEY:
        return jsonify({"error": "Server par GEMINI_API_KEY environment variable set nahi hai."}), 503
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"error": "Message khali hai."}), 400
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
    try:
        r = requests.post(
            url,
            headers={"x-goog-api-key": GEMINI_API_KEY, "Content-Type": "application/json"},
            json={
                "systemInstruction": {"parts": [{"text": SYSTEM_INSTRUCTION}]},
                "contents": [{"role": "user", "parts": [{"text": message}]}],
                "generationConfig": {"temperature": 0.7, "maxOutputTokens": 900}
            },
            timeout=45,
        )
        if not r.ok:
            return jsonify({"error": f"Gemini API error ({r.status_code}): {r.text[:500]}"}), 502
        payload = r.json()
        parts = payload.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        answer = "
".join(p.get("text", "") for p in parts if p.get("text"))
        if not answer:
            answer = "Gemini se text jawab nahi mila."
        return jsonify({"reply": answer})
    except requests.RequestException:
        return jsonify({"error": "Gemini service se connection nahi ho saka."}), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8080")))
