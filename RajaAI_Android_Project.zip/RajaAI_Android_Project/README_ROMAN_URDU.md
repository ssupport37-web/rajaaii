# RAJA AI — Android + Gemini

## Project mein kya hai?
- Native Android Kotlin + Jetpack Compose app
- Roman Urdu chat UI
- Android speech recognition (ur-PK preference)
- Android Text-to-Speech (Urdu voice available ho to use karta hai; male voice device par depend karti hai)
- Local commands: YouTube kholo, Google kholo, Settings kholo, time batao, tareekh batao
- Gemini backend alag rakha gaya hai taa-ke API key APK ke andar expose na ho

## Zaroori baat
Yeh source project hai, ready-made signed APK nahi. APK banane ke liye Android Studio mein build karna hoga. Is environment mein Android SDK/Gradle build verify nahi kiya gaya.

## 1. Gemini backend Render par deploy karein
1. `backend` folder ko GitHub repository mein upload karein (ya alag backend repo banayein).
2. Render par New > Web Service select karke repository connect karein.
3. Root Directory `backend` set karein (agar poora project same repo mein hai).
4. Build command: `pip install -r requirements.txt`
5. Start command: `gunicorn app:app`
6. Environment Variables mein `GEMINI_API_KEY` add karein. API key sirf server par rakhein, Android app ya GitHub mein kabhi nahi.
7. `GEMINI_MODEL` optional hai; default `gemini-2.5-flash`.
8. Deploy hone ke baad HTTPS service URL copy karein.

Gemini API key Google AI Studio se apne account ke liye banayein. API key private rakhein.

## 2. Android app build karein
1. Android Studio install/open karein.
2. `rajaai_android` folder ko Open karein.
3. Gradle sync complete hone dein. JDK 17 use karein.
4. Phone ko USB debugging ke saath connect karein ya emulator start karein.
5. Run button dabayein.
6. App ke Settings mein Render ka HTTPS backend URL paste karein aur Save karein.
7. Microphone permission allow karein.

APK banane ke liye: Build > Build Bundle(s) / APK(s) > Build APK(s). Debug APK aam tor par `app/build/outputs/apk/debug/app-debug.apk` mein milegi.

## 3. Android voice notes
- Speech recognition Android ke installed speech service par depend karti hai; ur-PK availability har phone par guaranteed nahi.
- Male voice guaranteed nahi: app Urdu voice select karne ki koshish karti hai aur male-named voice available ho to prefer karti hai. Warna device ki default voice chalegi.
- Microphone ke liye internet ya device speech service ki zaroorat ho sakti hai.

## 4. Current supported voice commands
- "YouTube kholo"
- "Google kholo"
- "Settings kholo"
- "Time batao" / "Waqt batao"
- "Date batao" / "Tareekh batao"

App sirf listed, explicit supported actions ko execute karti hai. Baqi requests Gemini ko chat ke liye bheji jati hain.

## 5. Security
- Gemini key APK mein embed nahi hoti.
- Backend HTTPS use karta hai.
- Public backend par rate limiting/authentication add karna production ke liye recommended hai.
- API usage par Google account ke billing/quota rules apply ho sakte hain.
